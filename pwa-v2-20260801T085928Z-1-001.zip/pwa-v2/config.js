// عدّل القيمتين دول بعد نشر Apps Script (راجع دليل النشر)
window.OP_CONFIG = {
  API_URL: "PASTE_YOUR_WEB_APP_URL_HERE",
  API_TOKEN: "PASTE_YOUR_TOKEN_HERE",
};
